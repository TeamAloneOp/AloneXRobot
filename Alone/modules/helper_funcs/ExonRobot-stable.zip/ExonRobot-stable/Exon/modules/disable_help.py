from Alone.modules.language import gs


def get_help(chat):
    return gs(chat, "disable_help")


__mod_name__ = "𝐃ɪsᴀʙʟᴇ"
